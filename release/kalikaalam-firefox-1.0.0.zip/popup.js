/* Kalikaalam action popup — deliberately framework-free so it opens instantly. */
/* global KK_CITIES */
(() => {
  'use strict';

  const ACCENT = '#5ee7ff';
  const SECOND = '#ff2d4f';
  const MUTED = '#8aa4c0';

  const CITY_BY_ID = new Map(KK_CITIES.map((c) => [c.id, c]));
  const CONFIG_KEY = 'chronosphere:v1:config';

  const $ = (id) => document.getElementById(id);
  const canvas = $('dial');
  const ctx = canvas.getContext('2d');

  // Mirrors src/App.jsx DEFAULTS so a fresh profile still shows something.
  let cfg = {
    is24Hour: true,
    showSeconds: true,
    favorites: ['newdelhi', 'london', 'newyork'],
    timezones: ['newdelhi', 'mumbai', 'london', 'newyork', 'tokyo', 'dubai', 'singapore', 'sydney'],
  };

  try {
    const raw = localStorage.getItem(CONFIG_KEY);
    if (raw) cfg = { ...cfg, ...JSON.parse(raw) };
  } catch {
    /* first run — defaults are fine */
  }

  /* ------------------------------ formatting ------------------------------ */

  const fmtCache = new Map();

  function parts(tz) {
    let dtf = fmtCache.get(tz);
    if (!dtf) {
      try {
        dtf = new Intl.DateTimeFormat('en-US', {
          timeZone: tz,
          hourCycle: 'h23',
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
          weekday: 'short',
          month: 'short',
          day: '2-digit',
        });
      } catch {
        dtf = null;
      }
      fmtCache.set(tz, dtf);
    }
    if (!dtf) {
      const d = new Date();
      return {
        hour: d.getHours(), minute: d.getMinutes(), second: d.getSeconds(),
        weekday: 'Today', month: 'Mon', day: d.getDate(),
      };
    }
    const out = {};
    for (const { type, value } of dtf.formatToParts(new Date())) {
      if (type === 'weekday') out.weekday = value;
      else if (type !== 'literal') out[type] = type === 'hour' || type === 'day' ? Number(value) : value;
    }
    return out;
  }

  const pad = (n) => String(n).padStart(2, '0');

  function clockText(p) {
    let h = p.hour;
    let suffix = '';
    if (!cfg.is24Hour) {
      suffix = h >= 12 ? 'PM' : 'AM';
      h = h % 12 || 12;
    }
    const base = `${cfg.is24Hour ? pad(h) : h}:${pad(p.minute)}`;
    return cfg.showSeconds ? `${base}:${pad(p.second)}` : base;
  }

  const dateText = (p) =>
    `${p.weekday} ${p.month} ${p.day}`;

  /** Coarse local-time period used for the little accent bars. */
  function periodOf(tz) {
    try {
      const s = new Intl.DateTimeFormat('en-US', {
        timeZone: tz, hourCycle: 'h23', hour: '2-digit', minute: '2-digit',
      }).formatToParts(new Date());
      const h = Number(s.find((x) => x.type === 'hour')?.value ?? 12);
      if (h >= 6 && h < 17) return ACCENT;
      if (h >= 17 && h < 20) return '#fb923c';
      return '#818cf8';
    } catch {
      return ACCENT;
    }
  }

  /* -------------------------------- dial -------------------------------- */

  const R = canvas.width / 2;

  function drawDial(now) {
    const dpr = window.devicePixelRatio || 1;
    const size = 92;
    if (canvas.width !== size * dpr) {
      canvas.width = size * dpr;
      canvas.height = size * dpr;
    }
    const c = R;
    const r = size * dpr * 0.4;

    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.scale(dpr, dpr);
    ctx.translate(size / 2, size / 2);

    ctx.strokeStyle = 'rgba(94,231,255,0.5)';
    ctx.lineWidth = 1.6;
    ctx.beginPath();
    ctx.arc(0, 0, r, 0, Math.PI * 2);
    ctx.stroke();

    for (let i = 0; i < 12; i += 1) {
      const a = ((i * 30 - 90) * Math.PI) / 180;
      const outer = r * 0.92;
      const inner = r * (i % 3 === 0 ? 0.76 : 0.83);
      ctx.strokeStyle = i % 3 === 0 ? ACCENT : 'rgba(255,255,255,0.28)';
      ctx.lineWidth = i % 3 === 0 ? 1.6 : 1;
      ctx.beginPath();
      ctx.moveTo(Math.cos(a) * inner, Math.sin(a) * inner);
      ctx.lineTo(Math.cos(a) * outer, Math.sin(a) * outer);
      ctx.stroke();
    }

    const ms = now.getMilliseconds();
    const sec = now.getSeconds() + ms / 1000;
    const min = now.getMinutes() + sec / 60;
    const hr = (now.getHours() % 12) + min / 60;

    const arm = (angleDeg, len, width, color) => {
      const a = ((angleDeg - 90) * Math.PI) / 180;
      ctx.strokeStyle = color;
      ctx.lineWidth = width;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.lineTo(Math.cos(a) * len, Math.sin(a) * len);
      ctx.stroke();
    };

    arm(hr * 30, r * 0.5, 3.4, '#f2f7ff');
    arm(min * 6, r * 0.74, 2.4, '#f2f7ff');
    arm(sec * 6, r * 0.82, 1.1, SECOND);

    ctx.fillStyle = SECOND;
    ctx.beginPath();
    ctx.arc(0, 0, 2.4, 0, Math.PI * 2);
    ctx.fill();
  }

  /* ------------------------------- render -------------------------------- */

  function renderZones() {
    // Favourites are the headline; fall back to the full list if none are pinned.
    const favs = (cfg.favorites || []).filter((id) => CITY_BY_ID.has(id));
    const ids = (favs.length ? favs : cfg.timezones || [])
      .filter((id, i, arr) => arr.indexOf(id) === i)
      .slice(0, 4);
    const host = $('zones');
    host.textContent = '';

    if (!ids.length) {
      $('empty').hidden = false;
      return;
    }
    $('empty').hidden = true;

    host.style.gridTemplateColumns = `repeat(${ids.length}, minmax(0, 1fr))`;
    const frag = document.createDocumentFragment();
    for (const id of ids) {
      const city = CITY_BY_ID.get(id);
      if (!city) continue;
      const p = parts(city.tz);
      const el = document.createElement('div');
      el.className = 'zone';
      el.style.setProperty('--accent', periodOf(city.tz));
      el.innerHTML =
        `<em></em><u></u>`;
      el.querySelector('em').textContent = city.city;
      // HH:MM only in the small cards — seconds would clip at this width.
      const short = cfg.is24Hour ? `${pad(p.hour)}:${pad(p.minute)}` : `${p.hour % 12 || 12}:${pad(p.minute)}`;
      el.querySelector('u').textContent = short;
      frag.appendChild(el);
    }
    host.appendChild(frag);
  }

  function tick() {
    const now = new Date();
    const tz = cfg.timezone && cfg.timezone !== 'local' ? cfg.timezone : undefined;
    const p = tz ? parts(tz) : parts(Intl.DateTimeFormat().resolvedOptions().timeZone);

    $('time').innerHTML = `${clockText(p)}${
      !cfg.is24Hour ? `<i>${p.hour >= 12 ? 'PM' : 'AM'}</i>` : ''
    }`;
    $('date').textContent = dateText(p);
    drawDial(now);
  }

  /* ------------------------------- actions ------------------------------- */

  $('open').addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('index.html') });
    window.close();
  });
  $('options').addEventListener('click', () => {
    chrome.runtime.openOptionsPage();
    window.close();
  });

  renderZones();
  tick();
  setInterval(tick, 1000);
})();
