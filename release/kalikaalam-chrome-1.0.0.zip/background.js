/**
 * Background service worker.
 *
 * Its only real job is keeping `chrome.alarms` in step with the alarm list
 * the UI stores, so a notification still fires when no Kalikaalam tab is open.
 */

const KEY = 'chronosphere:alarms';
const PREFIX = 'alarm:';
const MIN_LEAD_MS = 30_000; // chrome.alarms refuses anything sooner

const readAlarms = async () => {
  try {
    const bag = await chrome.storage.local.get(KEY);
    return Array.isArray(bag[KEY]) ? bag[KEY] : [];
  } catch {
    return [];
  }
};

/** Next occurrence of an "HH:MM" wall-clock time, at least MIN_LEAD_MS away. */
function nextOccurrence(hhmm) {
  const [h, m] = String(hhmm).split(':').map(Number);
  if (!Number.isFinite(h) || !Number.isFinite(m)) return null;

  const at = new Date();
  at.setHours(h, m, 0, 0);
  let when = at.getTime();

  const now = Date.now();
  while (when < now + MIN_LEAD_MS) when += 86_400_000;
  return when;
}

async function rebuild(list) {
  const alarms = list ?? (await readAlarms());

  await chrome.alarms.clearAll();

  for (const a of alarms) {
    if (!a?.enabled) continue;
    const when = nextOccurrence(a.time);
    if (when === null) continue;
    await chrome.alarms.create(`${PREFIX}${a.id}`, { when });
  }

  return { scheduled: (await chrome.alarms.getAll()).length };
}

chrome.runtime.onInstalled.addListener(() => rebuild());
chrome.runtime.onStartup.addListener(() => rebuild());

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === 'syncAlarms') {
    rebuild(msg.alarms).then(
      (r) => sendResponse({ ok: true, ...r }),
      (e) => sendResponse({ ok: false, error: String(e) })
    );
    return true; // keep the channel open for the async reply
  }
  if (msg?.type === 'ping') {
    sendResponse({ ok: true, version: chrome.runtime.getManifest().version });
    return false;
  }
  return undefined;
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (!alarm.name.startsWith(PREFIX)) return;

  const id = alarm.name.slice(PREFIX.length);
  const list = await readAlarms();
  const entry = list.find((x) => x.id === id);
  if (!entry) return;

  try {
    await chrome.notifications.create(`fired:${id}:${Date.now()}`, {
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: 'KaliKaalam',
      message: `${entry.label || 'Alarm'} — ${entry.time}`,
      priority: 2,
      requireInteraction: true,
    });
  } catch {
    /* notifications can be disabled at the OS level */
  }

  // Roll forward to tomorrow.
  rebuild(list);
});
